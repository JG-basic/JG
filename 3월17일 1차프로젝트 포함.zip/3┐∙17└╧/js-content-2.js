const title = document.querySelector("#title");
const Name = document.querySelector("#desc p");
const image = document.querySelector("#profile img");


title.onclick = () => {
    title.innerText = "프로필";
}

Name.onclick = () => {
    Name.innerHTML = "이름 : <b>민들레</b>";
}

image.onclick = () => {
    image.src = "d:/HTML/media/puppy.png";
}


