// const title = document.getElementById("#title");
// const pic = document.getElementsByClassName("img");
// const users = document.getElementsByTagName("user");

// title.addEventListener("click", function () {
//     if (title.innerText == "My profile") {
//         title.innerText = "프로필";
//     } else {
//         title.innerText = "My profile";
//     };
// });

// pic[0].addEventListener("click", function () {
//     pic[0].src = "puppy.png";
// });

// for (var i = 0; i < users.length; i++) {
//     users[i].addEventListener("click", function () {
//         if (this.innerText == "이름:도레미") {
//             this.innerText = "이름:진달래";
//             this.style.fontWeight = "bold";
//         } else if (this.innerText == "이름:진달래") {
//             this.innerText = "이름:도레미";
//             this.style.fontWeight = "normal";
//         }
//     });
// };

const title = document.getElementById("title");
const pic = document.getElementsByTagName("img");
const users = document.getElementsByClassName("user");

title.addEventListener("click", function () {
    title.innerText = title.innerText == "My Profile" ? "내 프로필" : "My Profile";
    // title.innerText = title.innerText == "My Profile" ? "내 프로필" : "My Profile";
    // title 객체의 innerText 속성 값을 변경하지 않습니다.
    // 삼항 연산자는 단지 조건에 따라 "내 프로필" 또는 "My Profile" 값을 반환할 뿐입니다.
    // 첫번째 부분 title.innerText = 는 반환된 값을 title.innerText에 할당하는 역할을 합니다.
    // title 객체의 텍스트가 조건에 따라 교대로 변경됩니다.(토글 효과)
});

pic[0].addEventListener("click", function () {
pic[0].src = pic[0].src.endsWith("d:/HTML/media/pf.png") ? "d:/HTML/media/puppy.png" : "d:/HTML/media/pf.png";
});
// endsWith() 함수는 문자열이 특정 문자열로 끝나는지 확인하는 JaveScript의 내장 함수입니다.
// 이미지의 소스 URL이 "girl.png" 로 끝나는지 확인

// pic[0].addEventListener("click", function () {
//     pic[0].src = "d:/HTML/media/puppy.png";
// });

for (var i = 0; i < users.length; i++) {
    users[i].addEventListener("click", function () {
        if (this.innerText == "이름 : 도레미") {
            this.innerText = "이름 : 진달래";
            this.style.fontWeight = "bold";
        } else if (this.innerText == "이름 : 진달래") {
            this.innerText = "이름 : 도레미";
            this.style.fontWeight = "normal";
        }
    });
};

// for (var i = 0; i < pic.length; i++) {
//     pic[i].addEventListener("click", function () {
//         if (this.src == "d:/HTML/media/pf.png") {
//             this.src = "d:/HTML/media/puppy.png";
//         } else if (this.src == "d:/HTML/media/puppy.png") {
//             this.src = "d:/HTML/media/pf.png";
//         }
//     });
// };

// 여기에서 삼항 연산자를 사용하여 title.innerText가 "My Profile"이면 "내 프로필"로 변경하고,
// 그렇지 않으면 "My Profile"로 변경합니다. 이렇게 하면 클릭할 때마다 텍스트가 토글됩니다.

