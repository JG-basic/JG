const tree = ""

for (let i = 0; i < 10; i++);
console.log("나무찍기" + i);