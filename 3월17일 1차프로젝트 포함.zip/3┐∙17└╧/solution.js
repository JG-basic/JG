const n = document.querySelector("#number1");
const m = document.querySelector("#number2");
const button = document.querySelector("button");
let result = document.querySelector("#result");

button.onclick = function() {
    result.innerText = getGCD(n.Value, m.value);
}


function getGCD(n, m) {
    let max = n > m ? n : m;
    let GCD = 0;
    for (let i = 1; i <= max; i++) { //  1부터 max까지 반복
        if (n % i === 0 && m % i === 0){
            GCD = i; 
        }                            //  n과 m이 현재 숫자(i)로 나누어 떨어지는지를 확인
    }                                //  GCD에 업데이트 숫자(i)를 넣어줍니다(할당)
    return GCD;
}

// 함수는 두개의 인수 n과 m을 받아서 최대공약수를 찾습니다.
// 가장 큰 숫자를 찾아서 max 변수에 저장합니다.
// for 반복문을 사용하여 1부터 max 까지 반복하며,
// 동시에 n과 m이 현재 숫자(i)로 나누어 떨어지는지 확인합니다.
// 만약 두 숫자 모두 현재 숫자(i)로 나누어 떨어진다면,
// 최대공약수(GCD) 변수를 현재 숫자(i)로 업데이트합니다.
// 반복문이 끝나면 최대공약수(GCD)를 반환합니다.