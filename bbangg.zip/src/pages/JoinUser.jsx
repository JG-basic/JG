/*eslint-disable*/
import { UserJoin } from "../components/joinUs/joinUs";

const JoinUser = ({ setUserList, userlist }) => {
    return <UserJoin setUserList={setUserList} userlist={userlist} />
};

export default JoinUser;