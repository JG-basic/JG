/*eslint-disable*/
import { Shopp } from "../components/shoplist/shopp"

const Shop = () => {
    return <Shopp />
};

export default Shop;