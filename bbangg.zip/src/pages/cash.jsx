/*eslint-disable*/
import { ProductCash } from "../components/cash/ProductCash";

const Cash = () => {
    return <ProductCash />
};

export default Cash;