import { useState } from "react";
import { Link } from 'react-router-dom';
import { SubTitle } from "../header/subTitle/subTitle";
import "./LoginUs.css";

// React를 사용하여 구현된 로그인 페이지를 나타냅니다. 
// useState 훅을 사용하여 입력된 아이디와 비밀번호를 저장하고, 
// onChange 함수를 사용하여 입력값이 변경될 때마다 상태를 업데이트합니다.
// confirm 함수는 아이디와 비밀번호를 검증하여 로그인 여부를 결정합니다. 
// 로그인이 성공하면 setOnuser와 setPaycash 함수를 사용하여 inputId 값을 저장합니다. 
// 이후, Link를 사용하여 회원가입 페이지로 이동할 수 있도록 하였습니다.
export default function LoginUs({ setOnuser, userlist, setPaycash }) {
  const [inputId, setInputValue] = useState('');  // 입력값.
  const [inputPw, setInputValue2] = useState('');

  function onChangeInput(e) {
    if (e.target.name === 'Id') {
      setInputValue(e.target.value);
    } else {
      setInputValue2(e.target.value);
    }
  }

  function checkEnter(e) {
    if (e.keyCode === 13 && inputId !== '' && inputPw !== '') {
      confirm();
    }
  }

  function confirm() {
    const filteredInfo = userlist.filter((item) => item.userID === inputId);

    if (inputId && inputPw) {
      if (filteredInfo.length === 0 || inputPw !== filteredInfo[0].userPW) {
        alert('아이디 또는 비밀번호를 잘 못 입력하였습니다. 😡');
      } else {
        alert('로그인 성공!!!!!!!!!!! 😊');
        setOnuser(inputId);
        setPaycash([inputId]);
      }
    } else {
      alert('아이디,비밀번호를 입력해 주세요. 😡');
    }
  }
//   로그인 버튼을 클릭할 때 실행되며, 입력한 아이디와 비밀번호가 유효한지 확인합니다.
//   먼저 입력한 아이디가 userlist 배열에 있는지 확인합니다. 
//   filter() 메소드를 사용하여 userlist 배열에서 
//   userID가 입력한 아이디와 같은 요소들을 찾아 새로운 배열을 만들고, 
//   그 배열의 길이를 filteredInfo 변수에 할당합니다.  
//   그 다음, 입력한 아이디와 비밀번호가 모두 입력되어 있는지 확인합니다. 
//   입력이 누락된 경우, "아이디,비밀번호를 입력해 주세요. 😡" 라는 경고창을 띄웁니다.  
//   입력이 모두 완료된 경우, userlist에 입력한 아이디가 없거나 비밀번호가 맞지 않는 경우 
//   "아이디 또는 비밀번호를 잘 못 입력하였습니다. 😡" 라는 경고창을 띄웁니다.  
//   그렇지 않은 경우, "로그인 성공!!!!!!!!!!! 😊" 라는 알림창을 띄우고, 
//   setOnuser 함수와 setPaycash 함수를 사용하여 현재 로그인한 사용자의 아이디를 설정합니다
  return (
    <>
      <div className="Login_main">
        <SubTitle subTitleName={"LOGIN"} />
        <div className="Login_middle">
          <div className="Login">
            <div className="LoginTop_id">
              <label htmlFor="UserID">아이디</label>
              <input
                type="text"
                id="UserID"
                placeholder="아이디"
                maxLength={20}
                onChange={onChangeInput}
                onKeyDown={checkEnter}
                value={inputId}
                name='Id'
              />
            </div>
            <div className="LoginTop_pw">
              <label htmlFor="UserPW">비밀번호</label>
              <input
                type="password"
                id="UserPW"
                placeholder="비밀번호"
                maxLength={20}
                onChange={onChangeInput}
                onKeyDown={checkEnter}
                value={inputPw}
                name='Pw'
              />
            </div>
            <button className="LoginBtn" onClick={confirm}>로그인</button>
            <div className="save1">
              <input type="checkbox" id="check1" defaultChecked />
              보안접속
              <label htmlFor="check2">
                <input type="checkbox" id="check2" />
                아이디저장
              </label>
              <a href="../id_pw_search/id_pw_search.html">아이디/비밀번호 찾기</a>
            </div>
          </div>
        </div>
      </div>
      <div className="joinBtn">
        <strong>아직 회원이 아니세요?</strong>
        <p>
          회원이 되시면 할인쿠폰, 이벤트 참여 등 다양한 혜택을 누리실 수 있습니다.
          <br />
          가입해라 이것드라.
        </p>
        <Link to="/JoinUs">신규회원</Link>
            </div>
        </>
    );
}