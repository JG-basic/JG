import './subTitle.css';

export const SubTitle = ({ subTitleName }) => {
    return <h3 className="sub_title">{subTitleName}</h3>;
}