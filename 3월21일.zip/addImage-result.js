const today = new Date();   // 현재 날짜와 시간 정보를 담은 today 객체
const hrs = today.getHours();   // 현재 시간 중 시(hour) 정보 가져오기
const imageToToggle = document.getElementById("toggleImage")


imageToToggle.src = hrs < 12 ? "d:/HTML/3월21일/image1.jpg" : "d:/HTML/3월21일/image2.jpg";


function toggleImage() {
    if (imageToToggle.style.display === "none") {
        imageToToggle.style.display = "block";
    } else {
        imageToToggle.style.display = "none";
    }
}
