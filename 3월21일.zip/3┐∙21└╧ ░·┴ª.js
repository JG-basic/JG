const body = document.querySelector("body");
const container = document.querySelector("#container");



body.addEventListener("keydown", (e) => {
    var key = e.key;
    if( key === t) {
        container.removeChild(toggleImage);
    }
  
});