import React from 'react'
import { BrowserRouter, Routes, Route, Link, useLocation, Outlet } from "react-router-dom";

// 라우트(Route)는 프론트엔드에서 사용되는 용어로, 사용자가 웹 페이지에서 요청한 URL에 따라
// 적절한 컴포넌트를 렌더링하는 것을 말합니다.
// link는 주소만 바꿀 뿐, 페이지를 새로 불러오진 않습니다.
// npm install react-router-dom

function App() {
  return (
    <BrowserRouter>
        <Link to="/">home</Link>
        <Link to="/one">one</Link>
        <Link to="/two">two</Link>
        <Link to="/three">three</Link>
        {/* 라우트를 감싸줍니다 */}
        <Routes>
            <Route path="/" element={<Index />}/>
            <Route path="/one" element={<One name='licat' />}/>
            <Route path="/two" element={<Two />}/>
            <Route path="/three/*" element={<Outlet />}>
                <Route path="" element={<ThreeIndex />}/>
                <Route path="hojunone/" element={<ThreeOne />}/>
                <Route path="hojuntwo/" element={<ThreeTwo />}/>
                </Route>
                <Route path="/blog/:id" element={<Blog />}/>
      </Routes>
    </BrowserRouter>
  );
}
// /blog/123의 경우 :id는 123이 됩니다.
// :id 값을 사용하여 블로그 게시물의 내용을 렌더링 할 수 있습니다.

function Index(){
    return <h1>hello world0</h1>
}

function One({name}) {
    return <h1>{name} world1</h1>
}

function Two() {
    return <h1>hello world2</h1>
}

function three() {
    return <h1>hello world3</h1>
}

function Blog() {
    const location = useLocation()
    console.log(location)
    return <h1>hello Blog</h1>
}

function ThreeIndex() {
return <h1>hello ThreeIndex</h1>
}
function ThreeOne() {
return <h1>hello ThreeOne</h1>
}
function ThreeTwo() {
return <h1>hello ThreeTwo</h1>
}
export default App
