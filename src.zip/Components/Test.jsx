import style from './test.module.css';

export default function Test() {
    return (
        <div className={style.test}>Test 2</div>
    )
}
// 프로젝트 내에서 서로 다른 버전의 ESLint, ESLint 플러그인,
// 또는 구성이 서로 충돌하는 경우.
// 글로벌로 설치된 ESLint와 프로젝트 로컬 ESLint 설정이
// 충돌하는 경우