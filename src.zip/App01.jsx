import React from 'react'
import styled, {css} from 'styled-components';
// 스타일 적용하기 npm install styled-components Css-in-js
const One = css`
    color: red;
`; // One이라는 이름의 CSS 코드 조각을 생성합니다
const Two = css`
    border: 1px solid black;
`; // Two라는 이름의 CSS 코드 조각을 생성합니다
const Three = styled.div`
    ${One}
    ${Two}
` // Three라는 이름의 styled-component를 생성
  // styled-component는 One과 Two CSS 코드 조각을 결합
const App = () => {
    return (
        <Three>Lorem ipsum dolor</Three>
    );
}


export default App
