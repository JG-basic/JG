// const today = new Date(); //현재 날짜와 시간 정보를 담은 today 객체
// const hrs = today.getHours(); //현재 시간 중 시(hour) 정보 가져오기
// const container = document.querySelector("#container");
// let newImg = document.createElement("img");
// newImg.src = hrs < 12 ? "../image/spongebob.png" : "../image/elsa.png";
// container.appendChild(newImg);
// let isHidden = false;

// container.addEventListener("click", function () {
//     newImg.hidden = true; // 이미지 숨기기
// });

// document.addEventListener("keydown", function (event) {
//     if (event.code === "KeyT") {
//         // 't'를 누르면 이미지 보이기
//         newImg.hidden = false;
//     }
// });

const today = new Date();
const hrs = today.getHours();
const container = document.querySelector("#container");
const newImg = document.createElement("img");
newImg.src = hrs < 12 ? "spongebob.png" : "elsa.png";
container.appendChild(newImg);

container.addEventListener("click", function () {
    newImg.hidden = true; // 이미지 숨기기
});

document.addEventListener("keydown", function (event) {
    if (event.key === "t" || "T") {
        // 't'를 누르면 이미지 보이기
        newImg.hidden = false;
    }
});
