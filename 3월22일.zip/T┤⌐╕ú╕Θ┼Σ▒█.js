const body = document.body;
const container = document.querySelector("#container");

body.addEventListener("keydown", (e) => {
    var Display;
    if(e.key === 't' || e.key === 'T' ) {
        container.style.display == 'none' ? Display = 'block' : Display = 'none';
        container.style.display = Display;
    } 
});